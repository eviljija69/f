module.exports = async (client, node) => {

	client.logger.log(`Node "${node.options.identifier}" created.`, "log");

}